# ユーザー設定の保存と読み込みを担当します。設定変更に対応するためのインターフェースもここに含まれます。
import json

class SettingsManager:
    def __init__(self, settings_file='settings.json'):
        self.settings_file = settings_file
        self.settings = {"work_duration": 1500, "break_duration": 300}  # 初期設定（秒）

    def load_settings(self):
        try:
            with open(self.settings_file, 'r') as f:
                self.settings = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.save_settings()  # ファイルが存在しない、または読み込めない場合、初期設定で保存

    def save_settings(self):
        with open(self.settings_file, 'w') as f:
            json.dump(self.settings, f, indent=4)

    def get_setting(self, key):
        return self.settings.get(key, None)

    def set_setting(self, key, value):
        self.settings[key] = value
        self.save_settings()

    def get_work_duration(self):
        return self.get_setting('work_duration')

    def set_work_duration(self, duration):
        self.set_setting('work_duration', duration)

    def get_break_duration(self):
        return self.get_setting('break_duration')

    def set_break_duration(self, duration):
        self.set_setting('break_duration', duration)
